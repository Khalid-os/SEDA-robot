
void 	initScreenStateMachine(void);

void screenStateMachine(void);

void screenMessage(void);
void screenMessageIP(void);
extern uint8_t* messageText[];

